# long-distance-tucan3g
This is a suite for simulate long distance WiFi and WiMAX links with the simulator ns-3
